#include <iostream>
#include "ThreeDShapes.h"

using namespace std;

double ThreeDShapes::area() const {}
double ThreeDShapes::volume() const {}
