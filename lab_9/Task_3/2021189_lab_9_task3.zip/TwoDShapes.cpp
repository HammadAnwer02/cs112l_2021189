#include <iostream>
#include "TwoDShapes.h"

using namespace std;

double TwoDShapes::area() const {}
